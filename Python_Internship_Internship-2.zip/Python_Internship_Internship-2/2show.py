from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://shubhamikhar:Shubham#123@clusterone.75qen.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

for doc in coll.find():
    print(doc)
    print()
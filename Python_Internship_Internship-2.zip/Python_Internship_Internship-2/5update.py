from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://shubhamikhar:Shubham#123@clusterone.75qen.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

no=input('Enter Id: ')
hg={}
hg["_id"]=no

qr={}
salary=input('Enter new salary: ')
qr['salary']=salary

upd={"$set":qr}
coll.update_one(hg,upd)
print('Doccument updated Sucessfully')

for doc in coll.find(hg):
    print(doc)
    print()